const products = [
  {id:1, name:"Mini DIY Clay Kit", price:59000, tag:"NEW", image:"https://images.unsplash.com/photo-1596464716127-f2a82984de30?auto=format&fit=crop&w=700&q=85"},
  {id:2, name:"Cute Sticker Pack", price:29000, tag:"BEST SELLER", image:"https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=700&q=85"},
  {id:3, name:"Pastel Room Decor", price:79000, tag:"FAVORITE", image:"https://images.unsplash.com/photo-1513519245088-0e12902e5a38?auto=format&fit=crop&w=700&q=85"},
  {id:4, name:"DIY Beads Bracelet", price:45000, tag:"DIY", image:"https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?auto=format&fit=crop&w=700&q=85"},
  {id:5, name:"Scrapbook Starter Set", price:69000, tag:"NEW", image:"https://images.unsplash.com/photo-1517842645767-c639042777db?auto=format&fit=crop&w=700&q=85"},
  {id:6, name:"Cute Desk Trinket", price:39000, tag:"CUTE", image:"https://images.unsplash.com/photo-1494438639946-1ebd1d20bf85?auto=format&fit=crop&w=700&q=85"},
  {id:7, name:"Mini Gift Box Kit", price:55000, tag:"GIFT", image:"https://images.unsplash.com/photo-1549465220-1a8b9238cd48?auto=format&fit=crop&w=700&q=85"},
  {id:8, name:"Creative Washi Set", price:35000, tag:"SALE", image:"https://images.unsplash.com/photo-1452860606245-08befc0ff44b?auto=format&fit=crop&w=700&q=85"}
];

let cart = JSON.parse(localStorage.getItem("kstudioCart") || "[]");
let currentLang = localStorage.getItem("kstudioLang") || "id";

const i18n = {
  id: {
    announcement:"Gratis ongkir untuk pembelian tertentu • Temukan barang DIY favoritmu!",
    navHome:"Home", navShop:"Shop", navPromo:"Promo", navAbout:"About", navInspiration:"Inspiration", navContact:"Contact",
    searchPlaceholder:"Cari barang DIY...", eyebrow:"MAKE • CREATE • PLAY",
    heroTitle:"Small things,<br><em>big joy.</em>",
    heroText:"Temukan barang DIY unik dan lucu untuk membuat hari-harimu lebih kreatif.",
    shopNow:"Belanja Sekarang", explore:"Jelajahi ide →",
    heroNote:"Dipilih untuk kamu yang suka hal-hal kecil yang istimewa.",
    slide1Tag:"NEW ARRIVAL", slide1Title:"Cute Craft Kit", slide1Text:"Paket DIY untuk waktu kreatifmu.",
    slide2Tag:"KSTUDIO PICKS", slide2Title:"Tiny Room Decor", slide2Text:"Dekor mungil untuk sudut favoritmu.",
    slide3Tag:"BEST SELLER", slide3Title:"Lovely Stationery", slide3Text:"Barang kecil yang bikin meja makin seru.",
    cat1:"DIY Kits", cat2:"Cute Goods", cat3:"Room Decor", cat4:"Stationery",
    shopEyebrow:"SHOP THE COLLECTION", shopTitle:"Little things you’ll love.", viewAll:"Lihat semua →",
    promoEyebrow:"KSTUDIO SPECIAL", promoTitle:"Bikin sendiri.<br>Hadiahkan dengan hati.",
    promoText:"Pilih DIY kit favorit dan ubah momen biasa jadi sesuatu yang memorable.", shopPromo:"Lihat Promo",
    aboutEyebrow:"HELLO, WE'RE KSTUDIO", aboutTitle:"A tiny corner for creative people.",
    aboutText:"KStudio hadir untuk mengumpulkan barang DIY, stationery, dekorasi, dan benda-benda unik yang membuat proses berkreasi terasa lebih menyenangkan.",
    meetUs:"Kenal lebih dekat →", inspirationEyebrow:"GET INSPIRED", inspirationTitle:"Ideas made for you.",
    idea1Title:"DIY Weekend", idea1Text:"Ide aktivitas kreatif santai di rumah.",
    idea2Title:"Gift Ideas", idea2Text:"Racik hadiah kecil yang terasa personal.",
    idea3Title:"Room Styling", idea3Text:"Bikin sudut kamar lebih playful.",
    newsletterTitle:"Stay in the cute loop.", newsletterText:"Dapatkan info produk baru, promo, dan inspirasi DIY.",
    join:"Gabung", cartTitle:"Keranjang", total:"Total", checkout:"Pesan via WhatsApp", chat:"Chat",
    footerText:"Made for curious hands & happy hearts.", empty:"Keranjangmu masih kosong."
  },
  en: {
    announcement:"Free shipping on selected orders • Find your new DIY favorite!",
    navHome:"Home", navShop:"Shop", navPromo:"Promo", navAbout:"About", navInspiration:"Inspiration", navContact:"Contact",
    searchPlaceholder:"Search DIY goods...", eyebrow:"MAKE • CREATE • PLAY",
    heroTitle:"Small things,<br><em>big joy.</em>",
    heroText:"Discover unique and cute DIY goods made to add more creativity to your everyday.",
    shopNow:"Shop Now", explore:"Explore ideas →",
    heroNote:"Picked for people who love little things with a special touch.",
    slide1Tag:"NEW ARRIVAL", slide1Title:"Cute Craft Kit", slide1Text:"A DIY kit for your creative time.",
    slide2Tag:"KSTUDIO PICKS", slide2Title:"Tiny Room Decor", slide2Text:"Little decor for your favorite corner.",
    slide3Tag:"BEST SELLER", slide3Title:"Lovely Stationery", slide3Text:"Tiny things that make your desk happier.",
    cat1:"DIY Kits", cat2:"Cute Goods", cat3:"Room Decor", cat4:"Stationery",
    shopEyebrow:"SHOP THE COLLECTION", shopTitle:"Little things you’ll love.", viewAll:"View all →",
    promoEyebrow:"KSTUDIO SPECIAL", promoTitle:"Make it yourself.<br>Give it with heart.",
    promoText:"Pick a favorite DIY kit and turn an ordinary moment into something memorable.", shopPromo:"View Promo",
    aboutEyebrow:"HELLO, WE'RE KSTUDIO", aboutTitle:"A tiny corner for creative people.",
    aboutText:"KStudio brings together DIY goods, stationery, decor and unique little objects that make creating more fun.",
    meetUs:"Meet us →", inspirationEyebrow:"GET INSPIRED", inspirationTitle:"Ideas made for you.",
    idea1Title:"DIY Weekend", idea1Text:"Easy creative activities for a slow weekend.",
    idea2Title:"Gift Ideas", idea2Text:"Create a little gift that feels personal.",
    idea3Title:"Room Styling", idea3Text:"Make your favorite corner more playful.",
    newsletterTitle:"Stay in the cute loop.", newsletterText:"Get new product drops, promos and DIY inspiration.",
    join:"Join", cartTitle:"Your Cart", total:"Total", checkout:"Order via WhatsApp", chat:"Chat",
    footerText:"Made for curious hands & happy hearts.", empty:"Your cart is empty."
  }
};

function rupiah(n) {
  return new Intl.NumberFormat("id-ID", {style:"currency", currency:"IDR", maximumFractionDigits:0}).format(n);
}

function renderProducts(list = products) {
  const grid = document.getElementById("productGrid");
  grid.innerHTML = list.map(p => `
    <article class="product-card">
      <div class="product-image">
        <img src="${p.image}" alt="${p.name}" loading="lazy">
        <span class="product-tag">${p.tag}</span>
        <button class="add-cart" data-id="${p.id}" aria-label="Add ${p.name} to cart">+</button>
      </div>
      <div class="product-info">
        <h3>${p.name}</h3>
        <p>${currentLang === "id" ? "Barang DIY unik & lucu" : "Unique & cute DIY good"}</p>
        <div class="product-price">${rupiah(p.price)}</div>
      </div>
    </article>
  `).join("");
  grid.querySelectorAll(".add-cart").forEach(btn => btn.addEventListener("click", () => addToCart(+btn.dataset.id)));
}

function saveCart() {
  localStorage.setItem("kstudioCart", JSON.stringify(cart));
}

function addToCart(id) {
  const item = cart.find(x => x.id === id);
  if (item) item.qty++;
  else cart.push({id, qty:1});
  saveCart();
  renderCart();
  openCart();
}

function changeQty(id, delta) {
  const item = cart.find(x => x.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) cart = cart.filter(x => x.id !== id);
  saveCart();
  renderCart();
}

function renderCart() {
  const wrap = document.getElementById("cartItems");
  const count = cart.reduce((s,x) => s+x.qty, 0);
  document.getElementById("cartCount").textContent = count;
  if (!cart.length) {
    wrap.innerHTML = `<div class="empty-cart">${i18n[currentLang].empty}</div>`;
    document.getElementById("cartTotal").textContent = rupiah(0);
    return;
  }
  let total = 0;
  wrap.innerHTML = cart.map(item => {
    const p = products.find(x => x.id === item.id);
    total += p.price * item.qty;
    return `
      <div class="cart-row">
        <img src="${p.image}" alt="${p.name}">
        <div>
          <h4>${p.name}</h4>
          <p>${rupiah(p.price)}</p>
          <div class="qty">
            <button data-id="${p.id}" data-delta="-1">−</button>
            <span>${item.qty}</span>
            <button data-id="${p.id}" data-delta="1">+</button>
          </div>
        </div>
        <div class="cart-price">${rupiah(p.price * item.qty)}</div>
      </div>
    `;
  }).join("");
  document.getElementById("cartTotal").textContent = rupiah(total);
  wrap.querySelectorAll(".qty button").forEach(b => b.addEventListener("click", () => changeQty(+b.dataset.id, +b.dataset.delta)));
}

function openCart() {
  document.getElementById("cartDrawer").classList.add("open");
  document.getElementById("overlay").classList.add("show");
}
function closeCart() {
  document.getElementById("cartDrawer").classList.remove("open");
  document.getElementById("overlay").classList.remove("show");
}

function applyLanguage(lang) {
  currentLang = lang;
  localStorage.setItem("kstudioLang", lang);
  document.documentElement.lang = lang === "id" ? "id" : "en";
  document.querySelectorAll("[data-i18n]").forEach(el => {
    const key = el.dataset.i18n;
    if (i18n[lang][key]) el.innerHTML = i18n[lang][key];
  });
  document.querySelectorAll("[data-placeholder]").forEach(el => {
    el.placeholder = i18n[lang][el.dataset.placeholder];
  });
  document.querySelectorAll(".lang-btn").forEach(b => b.classList.toggle("active", b.dataset.lang === lang));
  renderProducts();
  renderCart();
  updateWhatsApp();
}

function updateWhatsApp() {
  const msg = currentLang === "id"
    ? "Halo kak aku mau pesan DIY yang lucu .... 5 item ya;"
    : "Hi! I would like to order some cute DIY goods .... 5 items please;";
  document.getElementById("waButton").href = `https://wa.me/6281111806724?text=${encodeURIComponent(msg)}`;
}

let slideIndex = 0;
const slides = document.querySelectorAll(".slide");
const dots = document.getElementById("dots");
slides.forEach((_, i) => {
  const d = document.createElement("span");
  d.className = "dot" + (i === 0 ? " active" : "");
  d.addEventListener("click", () => showSlide(i));
  dots.appendChild(d);
});
function showSlide(i) {
  slideIndex = (i + slides.length) % slides.length;
  slides.forEach((s, n) => s.classList.toggle("active", n === slideIndex));
  document.querySelectorAll(".dot").forEach((d,n) => d.classList.toggle("active", n === slideIndex));
}
document.getElementById("prevSlide").addEventListener("click", () => showSlide(slideIndex - 1));
document.getElementById("nextSlide").addEventListener("click", () => showSlide(slideIndex + 1));
setInterval(() => showSlide(slideIndex + 1), 5000);

document.querySelectorAll(".lang-btn").forEach(b => b.addEventListener("click", () => applyLanguage(b.dataset.lang)));
document.getElementById("cartToggle").addEventListener("click", openCart);
document.getElementById("cartClose").addEventListener("click", closeCart);
document.getElementById("overlay").addEventListener("click", closeCart);

const searchPanel = document.getElementById("searchPanel");
document.getElementById("searchToggle").addEventListener("click", () => {
  searchPanel.classList.toggle("open");
  if (searchPanel.classList.contains("open")) document.getElementById("searchInput").focus();
});
document.getElementById("searchClose").addEventListener("click", () => searchPanel.classList.remove("open"));
document.getElementById("searchInput").addEventListener("input", e => {
  const q = e.target.value.toLowerCase().trim();
  const results = products.filter(p => p.name.toLowerCase().includes(q));
  document.getElementById("searchResults").innerHTML = q
    ? results.map(p => `<a class="search-result" href="#shop">${p.name} · ${rupiah(p.price)}</a>`).join("") || `<span class="search-result">Tidak ditemukan</span>`
    : "";
});

document.getElementById("checkoutBtn").addEventListener("click", () => {
  if (!cart.length) return;
  const lines = cart.map(item => {
    const p = products.find(x => x.id === item.id);
    return `${p.name} x${item.qty}`;
  });
  const message = currentLang === "id"
    ? `Halo kak aku mau pesan DIY yang lucu .... ${cart.reduce((s,x)=>s+x.qty,0)} item ya;\n\n${lines.join("\n")}\n\nTotal: ${document.getElementById("cartTotal").textContent}`
    : `Hi! I would like to order some cute DIY goods .... ${cart.reduce((s,x)=>s+x.qty,0)} items please;\n\n${lines.join("\n")}\n\nTotal: ${document.getElementById("cartTotal").textContent}`;
  window.open(`https://wa.me/6281111806724?text=${encodeURIComponent(message)}`, "_blank");
});

document.getElementById("newsletterForm").addEventListener("submit", e => {
  e.preventDefault();
  alert(currentLang === "id" ? "Terima kasih! Kamu sudah bergabung dengan KStudio ♡" : "Thank you! You’re now part of KStudio ♡");
  e.target.reset();
});

const menuToggle = document.getElementById("menuToggle");
menuToggle.addEventListener("click", () => {
  const nav = document.querySelector(".desktop-nav");
  const isOpen = nav.dataset.mobileOpen === "true";
  if (!isOpen) {
    nav.style.display = "flex";
    nav.style.position = "absolute";
    nav.style.top = "82px";
    nav.style.left = "0";
    nav.style.right = "0";
    nav.style.padding = "22px 6vw";
    nav.style.background = "var(--cream-2)";
    nav.style.flexDirection = "column";
    nav.style.borderBottom = "1px solid var(--line)";
    nav.dataset.mobileOpen = "true";
  } else {
    nav.removeAttribute("style");
    nav.dataset.mobileOpen = "false";
  }
});

applyLanguage(currentLang);
